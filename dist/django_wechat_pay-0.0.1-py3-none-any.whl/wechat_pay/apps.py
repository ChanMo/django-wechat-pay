from django.apps import AppConfig


class WechatPayConfig(AppConfig):
    name = 'wechat_pay'
